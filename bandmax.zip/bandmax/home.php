<!DOCTYPE HTML>
<!--
	Spatial by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->
<html>
	<head>
		<title>BandMax</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="landing">

		<!-- Header -->
			<header id="header" class="alt">
				<h1><strong><a href="index.php">BandMax</a></strong> </h1>
				
			</header>

			<a href="#menu" class="navPanelToggle"><span class="fa fa-bars"></span></a>

		<!-- Banner -->
			<section id="banner">
				<h2>WE HAVE</h2>
				<p>Qualty and branded items for our beloved buyers</p>
				<ul class="actions">
					<li><a href="index.php" class="button special big">Get Started</a></li>
				</ul>
			</section>

			<!-- One -->
				

		<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<ul class="icons">
						<li><a href="https://www.facebook.com/pg/bandmaxcomputer/photos/?ref=page_internal" class="icon fa-facebook"></a></li>
						
					</ul>
					<ul class="copyright">
						<li>&copy; BANDMAX</li>
						<li>Design: <a href="http://templated.co">BANDMAX</a></li>
						<li>Images: <a href="http://unsplash.com">Facebookpage</a></li>
					</ul>
				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>